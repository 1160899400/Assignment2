import java.io.FileOutputStream;  
import java.io.IOException;  
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.io.FileWriter;

import java.util.regex.*;

import java.io.*;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580200 
{
	
	public static Document docFile() throws IOException
	{
		String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie";
		String htmlName = "homepageofteacher.html";
		HttpRequest htmlfile = HttpRequest.get(url);
		htmlfile.receive(new File (htmlName));
		File input =new File(htmlName);
		Document doc = Jsoup.parse(input,"utf-8");
		return doc;
	}

	public static void main(String[] args) throws IOException 
	{
		Document homePage = docFile();
		Elements content1 = homePage.select("div[class = details col-md-10 col-sm-9 col-xs-7]");
		Elements content2 = homePage.select("div[class = details col-md-12 col-sm-12 col-xs-12]");
		Elements nameOfTeacher = content1.select("[class = title]");
		
		String regx1 = "[0-9]{3}-[0-9]{8}|[0-9]{11}|[0-9]{8}(?!@)";
		String regx2 = "[a-zA-z_0-9]+@+[a-zA-Z0-9]+(\\.[a-zA-Z]+)";
		String regx3 = "[\u7814]+[\u7a76]+[\u65b9]+[\u5411]+[\uff1a]+ [\u4e00-\u9fa5]{0,10}";
		Pattern p1 = Pattern.compile(regx1);
		Pattern p2 = Pattern.compile(regx2);
		Pattern p3 = Pattern.compile(regx3);
		String phoneNumber,email,directorOfStudy;
		
		Matcher m1 = p1.matcher(content1.text());
		Matcher m2 = p2.matcher(content1.text());
		Matcher m3 = p3.matcher(content1.text());
		
		FileWriter writer;
		try
		{
			writer = new FileWriter("homepageofteacher.txt");
			writer.write("������"+nameOfTeacher.text()+"\r\n");
			writer.write("���˼�飺"+content2.text()+"\r\n");
			while(m3.find())
			{
				directorOfStudy = m3.group();
				writer.write(directorOfStudy+"\r\n");
			}
			writer.write("�绰���룺");
			while(m1.find())
			{
				phoneNumber = m1.group();
				writer.write(phoneNumber+"     ");
			}
			writer.write("\r\n"+"�����ַ��");
			while(m2.find())
			{
				email = m2.group();
				writer.write(email+"     ");
			}
			
			writer.flush();
            writer.close();
		}
		catch (IOException e)
		{
            e.printStackTrace();
        }

	}

}
